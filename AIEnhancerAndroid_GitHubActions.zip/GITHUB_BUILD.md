# Сборка APK через GitHub Actions

1. Создай новый репозиторий на GitHub.
2. Загрузи все файлы этого проекта в репозиторий.
3. Открой вкладку **Actions**.
4. Выбери **Build Android APK**.
5. Нажми **Run workflow**.
6. После завершения открой запуск workflow и скачай artifact **AI-Enhancer-debug-apk**.
7. Внутри artifact будет файл `.apk`, который можно установить на Android.

Примечание: это debug APK. Для публикации в Google Play позже добавим release-подпись.
