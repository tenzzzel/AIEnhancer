package com.example.aienhancer

import android.content.ContentValues
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private var selectedUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            preview.setImageURI(uri)
            status.text = "Фото выбрано"
        }
    }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            preview.setImageResource(android.R.drawable.ic_media_play)
            status.text = "Видео выбрано. В этой первой версии подготовлен экран и экспортный контур."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val bg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.rgb(10,10,12))
        }

        val title = TextView(this).apply {
            text = "AI Enhancer"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        bg.addView(title, LinearLayout.LayoutParams(-1, 70))

        val sub = TextView(this).apply {
            text = "Улучшение фото и видео"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        bg.addView(sub, LinearLayout.LayoutParams(-1, 45))

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setBackgroundColor(Color.rgb(25,25,28))
            setImageResource(android.R.drawable.ic_menu_gallery)
        }
        bg.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Выберите файл"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        bg.addView(status, LinearLayout.LayoutParams(-1, 50))

        val photo = button("Выбрать фото") { pickImage.launch("image/*") }
        val video = button("Выбрать видео") { pickVideo.launch("video/*") }
        val enhance = button("✨ Улучшить фото") { enhancePhoto() }

        bg.addView(photo, lp())
        bg.addView(video, lp())
        bg.addView(enhance, lp())

        setContentView(bg)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, 58).apply { setMargins(0,8,0,0) }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 16f
        setOnClickListener { action() }
    }

    private fun enhancePhoto() {
        val uri = selectedUri ?: run {
            status.text = "Сначала выберите фото"
            return
        }
        try {
            val src = MediaStore.Images.Media.getBitmap(contentResolver, uri)
            status.text = "Обработка…"
            val enhanced = sharpen(src, 1.35f)
            preview.setImageBitmap(enhanced)
            saveBitmap(enhanced)
            status.text = "Готово — улучшенная копия сохранена"
        } catch (e: Exception) {
            status.text = "Не удалось обработать фото"
        }
    }

    private fun sharpen(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val p = IntArray(w * h)
        src.getPixels(p, 0, w, 0, 0, w, h)
        fun lum(c:Int) = 0.299f*Color.red(c)+0.587f*Color.green(c)+0.114f*Color.blue(c)
        for (y in 1 until h-1) for (x in 1 until w-1) {
            val i=y*w+x
            val center=p[i]
            val avg=(lum(p[i-1])+lum(p[i+1])+lum(p[i-w])+lum(p[i+w]))/4f
            val delta=(lum(center)-avg)*amount
            val r=min(255,max(0,(Color.red(center)+delta).toInt()))
            val g=min(255,max(0,(Color.green(center)+delta).toInt()))
            val b=min(255,max(0,(Color.blue(center)+delta).toInt()))
            p[i]=Color.argb(Color.alpha(center),r,g,b)
        }
        out.setPixels(p,0,w,0,0,w,h)
        return out
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "AI_Enhancer_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Enhancer")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
        contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    }
}
