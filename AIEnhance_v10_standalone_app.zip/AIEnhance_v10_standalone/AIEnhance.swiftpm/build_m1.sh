#!/bin/bash
set -e
cd "$(dirname "$0")"
swift build -c release
echo "Build complete."
