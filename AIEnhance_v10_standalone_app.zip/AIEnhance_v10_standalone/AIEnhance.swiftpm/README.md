# AI Enhance — standalone macOS app builder

Проект собирает **настоящий `AIEnhance.app`**, который запускается обычным двойным кликом и не требует открывать проект в Xcode.

## Требования

- Mac с Apple Silicon (M1/M2/M3/M4)
- macOS 14+
- установленный Swift / Xcode Command Line Tools. Сам Xcode открывать не нужно.

## Самый простой способ

В Finder дважды нажмите:

**`Build AIEnhance.command`**

Скрипт:

1. собирает Release-версию под `arm64`;
2. создаёт `dist/AIEnhance.app`;
3. формирует стандартный `Info.plist`;
4. копирует ресурсы;
5. выполняет локальную ad-hoc подпись;
6. автоматически запускает готовое приложение.

## Через Terminal

```bash
./AIEnhance.swiftpm/build_app.sh
```

Готовое приложение будет здесь:

```text
dist/AIEnhance.app
```

## Важно

Эта упаковка не добавляет нейросетевые модели, которых нет в исходном проекте. Текущий `CoreMLModelStore` ожидает `RealESRGAN_x2plus.mlpackage` и `RealESRGAN_x4plus.mlpackage` в Resources. Если моделей нет, само приложение соберётся и запустится, но обработка через Real-ESRGAN завершится сообщением о том, что модель не добавлена.

Чтобы сделать полностью автономную версию с настоящим AI-upscale, модели нужно отдельно добавить в `Sources/AIEnhance/Resources` и проверить их совместимость с текущим Vision/Core ML pipeline.
