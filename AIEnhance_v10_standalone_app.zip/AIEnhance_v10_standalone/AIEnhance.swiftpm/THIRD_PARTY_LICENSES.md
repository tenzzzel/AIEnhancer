# Third-party model attribution

## Real-ESRGAN

Real-ESRGAN model weights are distributed under BSD-3-Clause according to the
model licensing documentation of the Superscale project.

Copyright 2021 Xintao Wang.

Model source/project:
https://github.com/XPixelGroup/Real-ESRGAN

Core ML release assets used by this app:
https://github.com/tigger04/superscale/releases/tag/models-v1

This application does not bundle GFPGAN weights.
