// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "AIEnhance",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "AIEnhance", targets: ["AIEnhance"])
    ],
    targets: [
        .executableTarget(
            name: "AIEnhance",
            resources: [.process("Resources")]
        )
    ]
)
