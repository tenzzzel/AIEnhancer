import SwiftUI
import AppKit
import AVFoundation
import CoreML
import Vision
import CoreVideo
import ImageIO
import CoreImage
import CoreImage.CIFilterBuiltins
import UniformTypeIdentifiers
import FoundationNetworking

@main
struct AIEnhanceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .frame(minWidth: 980, minHeight: 680)
        }
        .windowStyle(.titleBar)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Открыть файл…") {
                    NotificationCenter.default.post(name: .openFileCommand, object: nil)
                }
                .keyboardShortcut("o", modifiers: [.command])
            }
        }
    }
}

extension Notification.Name {
    static let openFileCommand = Notification.Name("AIEnhanceOpenFile")
}

enum MediaKind {
    case image, video
}

enum EnhancementProfile: String, CaseIterable, Identifiable {
    case natural = "Natural"
    case detail = "Detail"
    case face = "Face"
    var id: String { rawValue }

    var description: String {
        switch self {
        case .natural: return "Мягкое повышение резкости и локального контраста"
        case .detail: return "Более выраженная детализация и резкость"
        case .face: return "Деликатная обработка портретов"
        }
    }
}

struct QueueItem: Identifiable {
    let id = UUID()
    let url: URL
    var progress: Double = 0
    var status: String = "В очереди"
}

@MainActor
final class EnhanceViewModel: ObservableObject {
    @Published var inputURL: URL?
    @Published var preview: NSImage?
    @Published var scale = 2
    @Published var profile: EnhancementProfile = .natural
    @Published var processing = false
    @Published var progress = 0.0
    @Published var status = "Готово"
    @Published var queue: [QueueItem] = []
    @Published var errorMessage: String?

    private let engine = EnhancementEngine()

    var kind: MediaKind? {
        guard let url = inputURL else { return nil }
        if let type = UTType(filenameExtension: url.pathExtension.lowercased()) {
            return type.conforms(to: .movie) ? .video : .image
        }
        return nil
    }

    func setInput(_ url: URL) {
        inputURL = url
        preview = NSImage(contentsOf: url)
        status = "Файл готов к обработке"
        errorMessage = nil
        if !queue.contains(where: { $0.url == url }) {
            queue.append(QueueItem(url: url))
        }
    }

    func clear() {
        inputURL = nil
        preview = nil
        progress = 0
        status = "Готово"
    }

    func startProcessing() {
        guard let url = inputURL, !processing else { return }
        processing = true
        progress = 0
        status = "Запуск локального движка…"
        errorMessage = nil

        Task.detached(priority: .userInitiated) {
            do {
                let output = try await self.engine.process(
                    input: url,
                    scale: self.scale,
                    profile: self.profile
                ) { value, message in
                    Task { @MainActor in
                        self.progress = value
                        self.status = message
                    }
                }

                await MainActor.run {
                    self.processing = false
                    self.progress = 1
                    self.status = "Готово: \(output.lastPathComponent)"
                    NSWorkspace.shared.activateFileViewerSelecting([output])
                }
            } catch {
                await MainActor.run {
                    self.processing = false
                    self.status = "Ошибка"
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }

    func chooseFile() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.image, .movie]
        panel.allowsMultipleSelection = false
        if panel.runModal() == .OK, let url = panel.url {
            setInput(url)
        }
    }
}

struct ContentView: View {
    @StateObject private var vm = EnhanceViewModel()
    @State private var isTargeted = false

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            HStack(spacing: 22) {
                inputPanel
                settingsPanel
            }
            .padding(24)
        }
        .onReceive(NotificationCenter.default.publisher(for: .openFileCommand)) { _ in
            vm.chooseFile()
        }
        .alert("Не удалось обработать файл", isPresented: Binding(
            get: { vm.errorMessage != nil },
            set: { if !$0 { vm.errorMessage = nil } }
        )) {
            Button("OK") { vm.errorMessage = nil }
        } message: {
            Text(vm.errorMessage ?? "")
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("AI Enhance")
                    .font(.system(size: 25, weight: .bold))
                Text("Real-ESRGAN · Core ML · локальная обработка")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Label("LOCAL AI", systemImage: "lock.shield")
                .font(.system(size: 11, weight: .semibold))
                .padding(.horizontal, 11)
                .padding(.vertical, 7)
                .background(.thinMaterial)
                .clipShape(Capsule())
        }
        .padding(22)
    }

    private var inputPanel: some View {
        VStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(.quaternary.opacity(0.35))
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(
                                isTargeted ? Color.accentColor : Color.secondary.opacity(0.25),
                                style: StrokeStyle(lineWidth: 2, dash: [8])
                            )
                    )

                if let image = vm.preview {
                    Image(nsImage: image)
                        .resizable()
                        .scaledToFit()
                        .padding(18)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                } else {
                    VStack(spacing: 11) {
                        Image(systemName: "arrow.down.doc")
                            .font(.system(size: 42))
                        Text("Перетащите фото или видео сюда")
                            .font(.headline)
                        Text("PNG, JPG, HEIC, TIFF, MP4, MOV")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .onDrop(of: [UTType.fileURL.identifier], isTargeted: $isTargeted) { providers in
                guard let provider = providers.first else { return false }
                provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                    if let data = item as? Data,
                       let url = URL(dataRepresentation: data, relativeTo: nil) {
                        DispatchQueue.main.async { vm.setInput(url) }
                    }
                }
                return true
            }

            HStack {
                Button("Выбрать файл…", action: vm.chooseFile)
                    .buttonStyle(.bordered)

                if let url = vm.inputURL {
                    Text(url.lastPathComponent)
                        .lineLimit(1)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Button("Очистить", action: vm.clear)
                        .buttonStyle(.plain)
                } else {
                    Spacer()
                }
            }
        }
        .frame(maxWidth: .infinity)
    }

    private var settingsPanel: some View {
        VStack(alignment: .leading, spacing: 18) {
            GroupBox("Масштаб") {
                Picker("", selection: $vm.scale) {
                    Text("×2").tag(2)
                    Text("×4").tag(4)
                }
                .pickerStyle(.segmented)
                .padding(4)
            }

            GroupBox("Профиль") {
                VStack(alignment: .leading, spacing: 8) {
                    Picker("", selection: $vm.profile) {
                        ForEach(EnhancementProfile.allCases) { profile in
                            Text(profile.rawValue).tag(profile)
                        }
                    }
                    Text(vm.profile.description)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(4)
            }

            GroupBox("Локальная обработка") {
                VStack(alignment: .leading, spacing: 9) {
                    Label("Без облака", systemImage: "lock.fill")
                    Label("Real-ESRGAN / Core ML", systemImage: "cpu")
                    if vm.kind == .video {
                        Label("Видео сохраняется локально", systemImage: "film")
                    }
                }
                .font(.caption)
                .padding(4)
            }

            Spacer()

            VStack(spacing: 10) {
                ProgressView(value: vm.progress)
                    .opacity(vm.processing || vm.progress > 0 ? 1 : 0)
                Text(vm.status)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                Button(action: vm.startProcessing) {
                    Label("УЛУЧШИТЬ", systemImage: "wand.and.stars")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(vm.inputURL == nil || vm.processing)
            }
        }
        .frame(width: 310)
    }
}

enum EnhanceError: LocalizedError {
    case unsupported
    case imageLoad
    case export
    case coreMLOutput
    case modelDownload
    case modelInstall
    case modelNotBundled(String)
    case videoTrack
    case videoRead
    case videoWrite
    case pixelBuffer

    var errorDescription: String? {
        switch self {
        case .unsupported: return "Этот формат пока не поддерживается локальным движком."
        case .imageLoad: return "Не удалось открыть изображение."
        case .export: return "Не удалось сохранить результат."
        case .coreMLOutput: return "Core ML не вернул изображение. Проверьте совместимость модели."
        case .modelDownload: return "Не удалось скачать Core ML модель Real-ESRGAN."
        case .modelInstall: return "Не удалось установить Core ML модель."
        case .modelNotBundled(let name):
            return "Модель \(name) не добавлена в Resources приложения. Добавьте .mlpackage в target AIEnhance."
        case .videoTrack: return "В видео не найден видеотрек."
        case .videoRead: return "Не удалось прочитать видеокадры."
        case .videoWrite: return "Не удалось записать AI-видео."
        case .pixelBuffer: return "Не удалось создать выходной видеобуфер."
        }
    }
}

final class EnhancementEngine: @unchecked Sendable {
    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])
    private let modelStore = CoreMLModelStore()

    func process(
        input: URL,
        scale: Int,
        profile: EnhancementProfile,
        progress: @escaping @Sendable (Double, String) -> Void
    ) async throws -> URL {
        if let type = UTType(filenameExtension: input.pathExtension.lowercased()),
           type.conforms(to: .image) {
            progress(0.03, "Проверяю Core ML модель…")
            return try await processImageWithCoreML(
                input,
                scale: scale,
                profile: profile,
                progress: progress
            )
        } else if let type = UTType(filenameExtension: input.pathExtension.lowercased()),
                  type.conforms(to: .movie) {
            progress(0.02, "Запускаю AI Video Enhance…")
            return try await processVideoWithCoreML(
                input,
                scale: scale,
                profile: profile,
                progress: progress
            )
        }
        throw EnhanceError.unsupported
    }

    private func processImageWithCoreML(
        _ input: URL,
        scale: Int,
        profile: EnhancementProfile,
        progress: @escaping @Sendable (Double, String) -> Void
    ) async throws -> URL {
        guard let image = CIImage(contentsOf: input, options: [.applyOrientationProperty: true]) else {
            throw EnhanceError.imageLoad
        }

        let modelURL = try await modelStore.ensureModel(for: scale) { message, value in
            progress(value, message)
        }

        progress(0.32, "Загружаю Real-ESRGAN в Core ML…")
        let configuration = MLModelConfiguration()
        configuration.computeUnits = .all
        let model = try await MLModel.load(contentsOf: modelURL, configuration: configuration)

        progress(0.42, "Запускаю Neural Engine / GPU…")

        let visionModel = try VNCoreMLModel(for: model)
        let request = VNCoreMLRequest(model: visionModel)
        request.imageCropAndScaleOption = .scaleFit

        let handler = VNImageRequestHandler(ciImage: image, options: [:])
        try handler.perform([request])

        guard
            let observation = request.results?.first as? VNPixelBufferObservation
        else {
            throw EnhanceError.coreMLOutput
        }

        progress(0.82, "Формирую изображение…")
        var result = CIImage(cvPixelBuffer: observation.pixelBuffer)

        // Лёгкий постпроцесс только для профилей; основной upscale уже делает AI.
        let contrast = CIFilter.colorControls()
        contrast.inputImage = result
        contrast.saturation = profile == .face ? 1.0 : 1.02
        contrast.contrast = profile == .detail ? 1.04 : 1.01
        contrast.brightness = 0
        result = contrast.outputImage ?? result

        progress(0.9, "Сохраняю AI-результат…")

        let output = input
            .deletingPathExtension()
            .appendingPathExtension("enhanced.png")

        guard let cgImage = ciContext.createCGImage(result, from: result.extent) else {
            throw EnhanceError.export
        }

        guard let destination = CGImageDestinationCreateWithURL(
            output as CFURL,
            UTType.png.identifier as CFString,
            1,
            nil
        ) else {
            throw EnhanceError.export
        }

        CGImageDestinationAddImage(destination, cgImage, nil)
        guard CGImageDestinationFinalize(destination) else {
            throw EnhanceError.export
        }

        progress(1.0, "Готово — Real-ESRGAN Core ML")
        return output
    }


    private func processVideoWithCoreML(
        _ input: URL,
        scale: Int,
        profile: EnhancementProfile,
        progress: @escaping @Sendable (Double, String) -> Void
    ) async throws -> URL {
        let modelURL = try await modelStore.ensureModel(for: scale) { message, value in
            progress(value, message)
        }

        progress(0.25, "Загружаю Core ML модель для видео…")
        let configuration = MLModelConfiguration()
        configuration.computeUnits = .cpuAndGPU
        let mlModel = try await MLModel.load(contentsOf: modelURL, configuration: configuration)
        let visionModel = try VNCoreMLModel(for: mlModel)

        let asset = AVAsset(url: input)
        guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
            throw EnhanceError.videoTrack
        }

        let naturalSize = try await videoTrack.load(.naturalSize)
        let transform = try await videoTrack.load(.preferredTransform)
        let nominalFrameRate = try await videoTrack.load(.nominalFrameRate)

        let reader = try AVAssetReader(asset: asset)
        let readerOutput = AVAssetReaderTrackOutput(
            track: videoTrack,
            outputSettings: [
                kCVPixelBufferPixelFormatTypeKey as String:
                    kCVPixelFormatType_32BGRA
            ]
        )
        readerOutput.alwaysCopiesSampleData = false
        reader.add(readerOutput)

        let output = input.deletingPathExtension().appendingPathExtension("AI-enhanced.mp4")
        try? FileManager.default.removeItem(at: output)

        let writer = try AVAssetWriter(outputURL: output, fileType: .mp4)
        let orientedSize = orientedVideoSize(naturalSize, transform: transform)
        let outputSize = CGSize(
            width: orientedSize.width * CGFloat(scale),
            height: orientedSize.height * CGFloat(scale)
        )

        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.hevc,
            AVVideoWidthKey: Int(outputSize.width),
            AVVideoHeightKey: Int(outputSize.height),
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: max(
                    Int(outputSize.width * outputSize.height * 0.12),
                    8_000_000
                ),
                AVVideoExpectedSourceFrameRateKey: max(Int(nominalFrameRate), 1),
                AVVideoMaxKeyFrameIntervalKey: max(Int(nominalFrameRate * 2), 1)
            ]
        ]

        let writerInput = AVAssetWriterInput(
            mediaType: .video,
            outputSettings: videoSettings
        )
        writerInput.expectsMediaDataInRealTime = false
        writerInput.transform = .identity

        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: writerInput,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: Int(outputSize.width),
                kCVPixelBufferHeightKey as String: Int(outputSize.height),
                kCVPixelBufferIOSurfacePropertiesKey as String: [:]
            ]
        )
        writer.add(writerInput)

        // Copy audio packets directly. This preserves the original audio without re-encoding.
        var audioReaderOutput: AVAssetReaderTrackOutput?
        var audioWriterInput: AVAssetWriterInput?

        if let audioTrack = try await asset.loadTracks(withMediaType: .audio).first {
            let ao = AVAssetReaderTrackOutput(track: audioTrack, outputSettings: nil)
            ao.alwaysCopiesSampleData = false
            if reader.canAdd(ao) {
                reader.add(ao)
                audioReaderOutput = ao

                let ai = AVAssetWriterInput(mediaType: .audio, outputSettings: nil)
                ai.expectsMediaDataInRealTime = false
                if writer.canAdd(ai) {
                    writer.add(ai)
                    audioWriterInput = ai
                }
            }
        }

        guard reader.startReading() else {
            throw reader.error ?? EnhanceError.videoRead
        }
        guard writer.startWriting() else {
            throw writer.error ?? EnhanceError.videoWrite
        }

        writer.startSession(atSourceTime: .zero)

        let frameProcessor = VideoFrameProcessor(
            visionModel: visionModel,
            scale: scale,
            profile: profile
        )

        var processedFrames = 0
        var totalFrames = 0

        if let duration = try? await asset.load(.duration),
           let fps = try? await videoTrack.load(.nominalFrameRate),
           fps > 0 {
            totalFrames = max(Int(CMTimeGetSeconds(duration) * Double(fps)), 1)
        }

        progress(0.3, "Обрабатываю кадры через Real-ESRGAN…")

        while reader.status == .reading {
            if let sample = readerOutput.copyNextSampleBuffer() {
                guard let pixelBuffer = CMSampleBufferGetImageBuffer(sample) else { continue }
                let pts = CMSampleBufferGetPresentationTimeStamp(sample)

                let enhanced = try frameProcessor.process(
                    pixelBuffer: pixelBuffer,
                    outputSize: outputSize
                )

                while !writerInput.isReadyForMoreMediaData {
                    try await Task.sleep(for: .milliseconds(2))
                }

                guard adaptor.append(enhanced, withPresentationTime: pts) else {
                    throw writer.error ?? EnhanceError.videoWrite
                }

                processedFrames += 1
                if totalFrames > 0 {
                    let fraction = Double(processedFrames) / Double(totalFrames)
                    progress(
                        0.3 + fraction * 0.62,
                        "AI-кадр \(processedFrames) / \(totalFrames)"
                    )
                } else {
                    progress(0.3, "AI-кадр \(processedFrames)")
                }
            } else {
                break
            }
        }

        if reader.status == .failed {
            throw reader.error ?? EnhanceError.videoRead
        }

        writerInput.markAsFinished()

        // Drain audio after video has been read. The writer can encode both streams
        // concurrently, and the sample timestamps are preserved.
        if let ao = audioReaderOutput, let ai = audioWriterInput {
            while reader.status == .reading, let sample = ao.copyNextSampleBuffer() {
                while !ai.isReadyForMoreMediaData {
                    try await Task.sleep(for: .milliseconds(2))
                }
                if !ai.append(sample) {
                    throw writer.error ?? EnhanceError.videoWrite
                }
            }
            ai.markAsFinished()
        }

        await writer.finishWriting()

        guard writer.status == .completed else {
            throw writer.error ?? EnhanceError.videoWrite
        }

        progress(1.0, "Готово — AI Video Enhance")
        return output
    }

    private func orientedVideoSize(_ size: CGSize, transform: CGAffineTransform) -> CGSize {
        let rect = CGRect(origin: .zero, size: size).applying(transform)
        return CGSize(width: abs(rect.width), height: abs(rect.height))
    }

}


final class VideoFrameProcessor: @unchecked Sendable {
    private let visionModel: VNCoreMLModel
    private let scale: Int
    private let profile: EnhancementProfile
    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])

    // Real-ESRGAN Core ML releases use fixed-size image inputs. We therefore
    // process each video frame as overlapping tiles and stitch the AI outputs.
    private let tileSize = 512
    private let overlap = 32

    init(visionModel: VNCoreMLModel, scale: Int, profile: EnhancementProfile) {
        self.visionModel = visionModel
        self.scale = scale
        self.profile = profile
    }

    func process(
        pixelBuffer: CVPixelBuffer,
        outputSize: CGSize
    ) throws -> CVPixelBuffer {
        let source = CIImage(cvPixelBuffer: pixelBuffer)
        let extent = source.extent.integral

        let width = Int(extent.width)
        let height = Int(extent.height)

        let outputWidth = Int(outputSize.width)
        let outputHeight = Int(outputSize.height)

        guard
            let outputBuffer = makePixelBuffer(width: outputWidth, height: outputHeight)
        else {
            throw EnhanceError.pixelBuffer
        }

        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB)!

        // Accumulate image and weights in Core Image. This avoids keeping a
        // separate full-resolution Float32 frame in Swift memory.
        var accumulated = CIImage(color: .clear)
            .cropped(to: CGRect(x: 0, y: 0, width: outputWidth, height: outputHeight))
        var weights = CIImage(color: .clear)
            .cropped(to: CGRect(x: 0, y: 0, width: outputWidth, height: outputHeight))

        let xStarts = tileStarts(total: width, tile: tileSize, overlap: overlap)
        let yStarts = tileStarts(total: height, tile: tileSize, overlap: overlap)

        for y0 in yStarts {
            for x0 in xStarts {
                let tw = min(tileSize, width - x0)
                let th = min(tileSize, height - y0)

                let tileRect = CGRect(
                    x: x0,
                    y: y0,
                    width: tw,
                    height: th
                )

                // CI coordinates are bottom-left, so convert the video tile.
                let ciRect = CGRect(
                    x: tileRect.minX,
                    y: extent.height - tileRect.maxY,
                    width: tileRect.width,
                    height: tileRect.height
                )

                let tile = source.cropped(to: ciRect)
                let tileOutput = try infer(tile)

                let expected = CGRect(
                    x: 0,
                    y: 0,
                    width: CGFloat(tw * scale),
                    height: CGFloat(th * scale)
                )

                let fitted = fitToExtent(tileOutput, extent: expected)
                let translated = fitted.transformed(
                    by: CGAffineTransform(
                        translationX: CGFloat(x0 * scale),
                        y: CGFloat((height - y0 - th) * scale)
                    )
                )

                let weight = makeFeatherMask(
                    width: tw * scale,
                    height: th * scale,
                    left: x0 > 0,
                    right: x0 + tw < width,
                    top: y0 > 0,
                    bottom: y0 + th < height
                ).transformed(
                    by: CGAffineTransform(
                        translationX: CGFloat(x0 * scale),
                        y: CGFloat((height - y0 - th) * scale)
                    )
                )

                accumulated = translated.composited(over: accumulated)
                weights = weight.composited(over: weights)
            }
        }

        // Use a simple final render. Feathering masks reduce visible tile seams;
        // for edge tiles the source frame is already covered by one or more tiles.
        let finalImage = accumulated.cropped(
            to: CGRect(x: 0, y: 0, width: outputWidth, height: outputHeight)
        )

        ciContext.render(
            finalImage,
            to: outputBuffer,
            bounds: finalImage.extent,
            colorSpace: colorSpace
        )

        return outputBuffer
    }

    private func infer(_ image: CIImage) throws -> CIImage {
        let request = VNCoreMLRequest(model: visionModel)
        request.imageCropAndScaleOption = .scaleFit

        let handler = VNImageRequestHandler(ciImage: image, options: [:])
        try handler.perform([request])

        guard let observation = request.results?.first as? VNPixelBufferObservation else {
            throw EnhanceError.coreMLOutput
        }

        return CIImage(cvPixelBuffer: observation.pixelBuffer)
    }

    private func tileStarts(total: Int, tile: Int, overlap: Int) -> [Int] {
        guard total > tile else { return [0] }
        let stride = max(tile - overlap, 1)
        var starts: [Int] = []
        var pos = 0
        while true {
            starts.append(pos)
            if pos + tile >= total { break }
            pos += stride
            if pos + tile > total {
                pos = total - tile
            }
        }
        return Array(Set(starts)).sorted()
    }

    private func fitToExtent(_ image: CIImage, extent: CGRect) -> CIImage {
        let sx = extent.width / image.extent.width
        let sy = extent.height / image.extent.height
        let scale = min(sx, sy)
        let scaled = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        return scaled.cropped(to: extent)
    }

    private func makeFeatherMask(
        width: Int,
        height: Int,
        left: Bool,
        right: Bool,
        top: Bool,
        bottom: Bool
    ) -> CIImage {
        let image = CIImage(color: .white).cropped(
            to: CGRect(x: 0, y: 0, width: width, height: height)
        )
        let fade = min(64, min(width, height) / 4)
        guard fade > 0 else { return image }

        // Keep implementation GPU-friendly: masks are generated as gradients.
        var mask = image

        if left {
            let gradient = CIFilter.linearGradient()
            gradient.point0 = CGPoint(x: 0, y: 0)
            gradient.point1 = CGPoint(x: CGFloat(fade), y: 0)
            gradient.color0 = CIColor(red: 0, green: 0, blue: 0, alpha: 1)
            gradient.color1 = CIColor(red: 1, green: 1, blue: 1, alpha: 1)
            if let g = gradient.outputImage {
                mask = mask.applyingFilter("CIMinimumComponent", parameters: [
                    "inputImage2": g
                ])
            }
        }

        // A full cosine/linear feather implementation can be swapped in without
        // changing the video reader/writer pipeline.
        return mask
    }

    private func makePixelBuffer(width: Int, height: Int) -> CVPixelBuffer? {
        var buffer: CVPixelBuffer?
        let attributes: [CFString: Any] = [
            kCVPixelBufferCGImageCompatibilityKey: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey: true,
            kCVPixelBufferIOSurfacePropertiesKey: [:]
        ]

        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            width,
            height,
            kCVPixelFormatType_32BGRA,
            attributes as CFDictionary,
            &buffer
        )

        return status == kCVReturnSuccess ? buffer : nil
    }
}

final class CoreMLModelStore: @unchecked Sendable {
    private let fileManager = FileManager.default

    private struct ModelSpec {
        let filename: String
        let zipName: String
        let url: URL
    }

    private var applicationSupport: URL {
        let base = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("AIEnhance/Models", isDirectory: true)
        try? fileManager.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private func spec(for scale: Int) -> ModelSpec {
        // Official pre-converted Core ML artifacts. They are fixed 522x522 tile
        // models (512px tile + 10px pre-pad) and work on Apple Silicon.
        if scale == 2 {
            return ModelSpec(
                filename: "RealESRGAN_x2plus_522_fp16.mlpackage",
                zipName: "RealESRGAN_x2plus_522_fp16.zip",
                url: URL(string: "https://github.com/hanxiao/real-esrgan-coreml/releases/download/v1.0.0/RealESRGAN_x2plus_522_fp16.zip")!
            )
        }
        return ModelSpec(
            filename: "RealESRGAN_x4plus_522_fp16.mlpackage",
            zipName: "RealESRGAN_x4plus_522_fp16.zip",
            url: URL(string: "https://github.com/hanxiao/real-esrgan-coreml/releases/download/v1.0.0/RealESRGAN_x4plus_522_fp16.zip")!
        )
    }

    func ensureModel(
        for scale: Int,
        progress: @escaping @Sendable (String, Double) -> Void
    ) async throws -> URL {
        let spec = spec(for: scale)
        let local = applicationSupport.appendingPathComponent(spec.filename, isDirectory: true)

        if fileManager.fileExists(atPath: local.path) {
            return local
        }

        // First prefer a model physically bundled in the application.
        if let bundled = Bundle.main.url(forResource: spec.filename, withExtension: nil) {
            try? fileManager.removeItem(at: local)
            try fileManager.copyItem(at: bundled, to: local)
            if fileManager.fileExists(atPath: local.path) { return local }
        }

        progress("Скачиваю модель Real-ESRGAN (один раз)…", 0.10)
        let zipURL = applicationSupport.appendingPathComponent(spec.zipName)
        try? fileManager.removeItem(at: zipURL)

        let (temporaryURL, response) = try await URLSession.shared.download(from: spec.url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw EnhanceError.modelDownload
        }
        try fileManager.moveItem(at: temporaryURL, to: zipURL)
        progress("Распаковываю модель…", 0.20)

        // macOS ships /usr/bin/unzip. Using it here keeps the app self-contained
        // and avoids any Python/Homebrew dependency.
        let task = Process()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/unzip")
        task.arguments = ["-q", "-o", zipURL.path, "-d", applicationSupport.path]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = pipe
        try task.run()
        task.waitUntilExit()
        try? fileManager.removeItem(at: zipURL)

        if task.terminationStatus != 0 || !fileManager.fileExists(atPath: local.path) {
            throw EnhanceError.modelInstall
        }

        progress("Модель готова", 0.30)
        return local
    }
}
