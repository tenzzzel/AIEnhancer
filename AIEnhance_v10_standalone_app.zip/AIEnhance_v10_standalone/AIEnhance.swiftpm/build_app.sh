#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
APP_NAME="AIEnhance"
APP_DIR="$SCRIPT_DIR/../dist/$APP_NAME.app"
BUILD_DIR="$SCRIPT_DIR/.build/arm64-apple-macosx/release"

if [[ "$(uname -m)" != "arm64" ]]; then
  echo "AIEnhance: нужен Mac Apple Silicon (M1/M2/M3/M4)."
  exit 1
fi
if ! command -v swift >/dev/null 2>&1; then
  echo "AIEnhance: не найден Swift. Установи Xcode Command Line Tools один раз: xcode-select --install"
  exit 1
fi

echo "== AIEnhance — Release arm64 =="
swift package resolve
swift build -c release --arch arm64
EXECUTABLE="$BUILD_DIR/$APP_NAME"
[[ -x "$EXECUTABLE" ]] || EXECUTABLE="$(find "$SCRIPT_DIR/.build" -type f -path '*/release/AIEnhance' -perm -111 -print -quit)"
[[ -x "$EXECUTABLE" ]] || { echo "Не найден бинарник AIEnhance"; exit 1; }

rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"
cp "$EXECUTABLE" "$APP_DIR/Contents/MacOS/$APP_NAME"
chmod +x "$APP_DIR/Contents/MacOS/$APP_NAME"

if [[ -d "$SCRIPT_DIR/Sources/AIEnhance/Resources" ]]; then
  cp -R "$SCRIPT_DIR/Sources/AIEnhance/Resources/." "$APP_DIR/Contents/Resources/" 2>/dev/null || true
fi

cat > "$APP_DIR/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDisplayName</key><string>AI Enhance</string>
<key>CFBundleExecutable</key><string>AIEnhance</string>
<key>CFBundleIdentifier</key><string>com.aienhance.app</string>
<key>CFBundleName</key><string>AIEnhance</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>2.0.0</string>
<key>CFBundleVersion</key><string>20</string>
<key>LSMinimumSystemVersion</key><string>14.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>LSApplicationCategoryType</key><string>public.app-category.photography</string>
</dict></plist>
PLIST

codesign --force --deep --sign - "$APP_DIR" >/dev/null 2>&1 || true

# Optional convenience copy to Desktop; the canonical app remains in dist/.
DESKTOP="$HOME/Desktop/AIEnhance.app"
rm -rf "$DESKTOP" 2>/dev/null || true
cp -R "$APP_DIR" "$DESKTOP" 2>/dev/null || true

printf '\nГотово: %s\n' "$APP_DIR"
printf 'Готовое приложение на рабочем столе: %s\n' "$DESKTOP"
printf 'Запускай именно AIEnhance.app двойным кликом — Xcode для работы приложения не нужен.\n'
