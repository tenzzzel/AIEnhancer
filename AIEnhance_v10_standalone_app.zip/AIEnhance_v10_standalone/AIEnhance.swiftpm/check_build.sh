#!/bin/bash
set -e
cd "$(dirname "$0")"
swift package resolve
swift build
