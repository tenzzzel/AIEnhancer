# AI Video Enhance architecture

1. AVAssetReaderTrackOutput декодирует video samples в BGRA CVPixelBuffer.
2. VideoFrameProcessor делит каждый frame на overlapping 512×512 tiles.
3. Каждая tile проходит через VNCoreMLRequest / Real-ESRGAN.
4. Результаты собираются в output frame масштаба ×2/×4.
5. AVAssetWriterInputPixelBufferAdaptor пишет кадры с исходными PTS.
6. Audio samples копируются напрямую в AVAssetWriter.
7. Выход сохраняется как `AI-enhanced.mp4`.

Для production-версии стоит добавить:
- bounded frame queues (decode → inference → encode);
- cancel/pause;
- resume/checkpoints;
- automatic tile size based on available memory;
- motion-aware temporal consistency;
- HDR / 10-bit preservation;
- source color primaries / transfer function propagation.
