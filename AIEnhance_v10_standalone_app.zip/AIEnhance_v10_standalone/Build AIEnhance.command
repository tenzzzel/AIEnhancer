#!/bin/bash
set -e
cd "$(dirname "$0")/AIEnhance.swiftpm"
./build_app.sh
open "../dist/AIEnhance.app"
