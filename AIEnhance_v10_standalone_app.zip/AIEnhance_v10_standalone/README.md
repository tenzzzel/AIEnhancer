# AI Enhance — standalone macOS app

Это не проект, который нужно запускать через Xcode. После сборки появляется настоящий `AIEnhance.app`.

## На Mac M1
1. Распакуй архив.
2. Дважды нажми `Build AIEnhance.command`.
3. Скрипт один раз компилирует приложение и кладёт готовый `AIEnhance.app` на Рабочий стол.
4. Дальше запускай **только `AIEnhance.app`** двойным кликом. `AIEnhance.swiftpm` больше открывать не нужно.

Для самой сборки нужен Swift из Xcode Command Line Tools; Xcode.app открывать не требуется. После сборки для работы AIEnhance.app Xcode не нужен.

## Модели
При первом нажатии «УЛУЧШИТЬ» приложение автоматически скачивает выбранную Core ML модель Real-ESRGAN и сохраняет её в `~/Library/Application Support/AIEnhance/Models`. После этого обработка выполняется локально.

Поддерживаются x2 и x4. Модели — предварительно сконвертированные Core ML артефакты Real-ESRGAN для Apple Silicon.
